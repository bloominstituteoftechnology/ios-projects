//
//  LoadingViewController.swift
//  LoadingUI
//
//  Created by Jonathan Ferrer on 6/26/19.
//  Copyright © 2019 Jonathan Ferrer. All rights reserved.
//


import UIKit

open class LoadingViewController: UIViewController {





    override open func viewDidLoad() {
        super.viewDidLoad()

        let loader = IndeterminateLoadingView(frame: view.frame)
        self.view.addSubview(loader)
        loader.startAnimating()

    }




    @IBAction func dismissModal(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

}
