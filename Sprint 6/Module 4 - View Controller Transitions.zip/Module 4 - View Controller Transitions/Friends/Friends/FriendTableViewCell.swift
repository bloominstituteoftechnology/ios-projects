//
//  FriendTableViewCell.swift
//  Friends
//
//  Created by Austin Cole on 1/10/19.
//  Copyright © 2019 Austin Cole. All rights reserved.
//

import UIKit

class FriendTableViewCell: UITableViewCell {
    @IBOutlet weak var friendNameLabel: UILabel!
    @IBOutlet weak var friendImagelabel: UIImageView!
    

}
