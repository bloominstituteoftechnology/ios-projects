import UIKit



class ImageTransitionAnimator: NSObject, UIViewControllerAnimatedTransitioning {
    let friendCell = FriendTableViewCell()
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        guard let sourceVC = transitionContext.viewController(forKey: .from) as? FriendsTableTableViewController,
            let destinationVC = transitionContext.viewController(forKey: .to) as? ViewController,
            let destinationView = transitionContext.view(forKey: .to) else {
                return
        }
        let containerView = transitionContext.containerView
        containerView.addSubview(destinationView)
        
        let destinationViewEndFrame = transitionContext.finalFrame(for: destinationVC)
        destinationView.frame = destinationViewEndFrame
        destinationView.alpha = 0.0
        
        let sourceLabel = friendCell.friendNameLabel!
        let sourceImage = friendCell.friendImagelabel!
        sourceLabel.alpha = 0.0
        sourceImage.alpha = 0.0
        
        let destinationLabel = destinationVC.friendName
        let destinationImage = destinationVC.friendImageView
        destinationLabel?.alpha = 0.0
        destinationImage?.alpha = 0.0
        
        let labelInitialFrame = containerView.convert((sourceLabel.bounds), from: sourceLabel)
        let imageInitialFrame = containerView.convert((sourceImage.bounds), from: sourceImage)
        
        let animatedLabel = UILabel(frame: labelInitialFrame)
        let animatedImage = UIImageView(frame: imageInitialFrame)
        animatedLabel.text = sourceLabel.text
        animatedLabel.font = sourceLabel.font
        animatedImage.image = sourceImage.image
        containerView.addSubview(animatedLabel)
        containerView.addSubview(animatedImage)
        
        let duration = transitionDuration(using: transitionContext)
        destinationView.layoutIfNeeded()
        UIView.animate(withDuration: duration, animations: {
            animatedLabel.frame = containerView.convert((destinationLabel?.bounds)!, from: destinationLabel)
            animatedImage.frame = containerView.convert((sourceImage.bounds), from: sourceImage)
            destinationView.alpha = 1.0
        }) { (success) in
            
            sourceLabel.alpha = 1.0
            sourceImage.alpha = 1.0
            
            destinationImage?.alpha = 1.0
            destinationLabel?.alpha = 1.0
            
            animatedLabel.removeFromSuperview()
            
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
}

